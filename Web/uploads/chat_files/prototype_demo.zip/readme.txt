TeamBox demo archive: Prototype Demo
